/*
  Sirah MapTap - browser side.

  Flow:
    1. GET /api/today      -> today's 3 prompts (names only, no coordinates)
    2. user taps map       -> we drop a temporary pin at the tap
    3. user hits Confirm   -> POST /api/guess {lat, lng}
    4. after 3rd confirm   -> server returns the reveal, we draw it
*/

// ---------- map setup ----------

// Esri World Imagery: real satellite tiles, free, no key. Attribution is required.
const satellite = L.tileLayer(
  "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
  {
    maxZoom: 17,
    attribution: "Imagery &copy; Esri, Maxar, Earthstar Geographics, and the GIS User Community",
  }
);

// Rough bounding box of the Hijaz so players can't wander off to Europe.
// [south-west corner, north-east corner]
const HIJAZ_BOUNDS = L.latLngBounds([17.5, 34.0], [30.5, 44.0]);

const map = L.map("map", {
  center: [23.5, 39.5],
  zoom: 6,
  minZoom: 5,
  maxBounds: HIJAZ_BOUNDS,
  maxBoundsViscosity: 0.8,   // how "sticky" the edge feels when you drag past it
  layers: [satellite],
  zoomControl: false,
});
L.control.zoom({ position: "bottomright" }).addTo(map);

// ---------- DOM handles ----------

const el = {
  roundLabel: document.getElementById("round-label"),
  prompt: document.getElementById("prompt"),
  hint: document.getElementById("hint"),
  confirm: document.getElementById("confirm"),
  panel: document.getElementById("panel"),
  reveal: document.getElementById("reveal"),
  revealDay: document.getElementById("reveal-day"),
  dailyScore: document.getElementById("daily-score"),
  results: document.getElementById("results"),
  devReset: document.getElementById("dev-reset"),
};

// ---------- game state (browser side only; the server is the authority) ----------

let prompts = [];        // [{round, id, name}, ...]
let currentRound = 0;    // 0-based index into prompts
let pendingGuess = null; // L.LatLng of the tap not yet confirmed
let pendingMarker = null;

const guessIcon = L.divIcon({ className: "pin pin-guess", iconSize: [14, 14] });
const answerIcon = L.divIcon({ className: "pin pin-answer", iconSize: [14, 14] });

// ---------- helpers ----------

async function api(path, options = {}) {
  // Relative URL on purpose: works on localhost now and on any host later.
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

function showRound(index) {
  const p = prompts[index];
  el.roundLabel.textContent = `Round ${p.round} of ${prompts.length}`;
  el.prompt.textContent = p.name;
  el.hint.textContent = "Tap the map to place your guess.";
  el.confirm.disabled = true;
  clearPending();
}

function clearPending() {
  if (pendingMarker) map.removeLayer(pendingMarker);
  pendingMarker = null;
  pendingGuess = null;
}

// ---------- event handlers ----------

map.on("click", (e) => {
  if (currentRound >= prompts.length) return;   // game finished, ignore taps
  pendingGuess = e.latlng;

  if (pendingMarker) {
    pendingMarker.setLatLng(e.latlng);          // move the existing pin
  } else {
    pendingMarker = L.marker(e.latlng, { icon: guessIcon }).addTo(map);
  }
  el.hint.textContent = "Tap again to move it, or confirm.";
  el.confirm.disabled = false;
});

el.confirm.addEventListener("click", async () => {
  if (!pendingGuess) return;
  el.confirm.disabled = true;

  try {
    const data = await api("/api/guess", {
      method: "POST",
      body: JSON.stringify({ lat: pendingGuess.lat, lng: pendingGuess.lng }),
    });

    clearPending();
    currentRound += 1;

    if (data.complete) {
      showReveal(data.reveal);
    } else {
      showRound(currentRound);
    }
  } catch (err) {
    el.hint.textContent = err.message;
    el.confirm.disabled = false;
  }
});

el.devReset.addEventListener("click", async () => {
  await api("/api/reset", { method: "POST" });
  location.reload();
});

// ---------- reveal ----------

function showReveal(reveal) {
  el.panel.hidden = true;
  el.reveal.hidden = false;
  el.revealDay.textContent = reveal.day;
  el.dailyScore.textContent = reveal.daily_score;
  el.results.innerHTML = "";

  const allPoints = [];

  reveal.results.forEach((r) => {
    const guess = [r.guess.lat, r.guess.lng];
    const answer = [r.answer.lat, r.answer.lng];
    allPoints.push(guess, answer);

    // Draw guess pin, answer pin, and the line between them.
    L.marker(guess, { icon: guessIcon }).addTo(map);
    L.marker(answer, { icon: answerIcon }).addTo(map).bindTooltip(r.name, { permanent: false });
    L.polyline([guess, answer], { color: "#b8543f", weight: 2, dashArray: "6 6" })
      .addTo(map)
      .bindTooltip(`${r.distance_km} km`, {
        permanent: true,
        direction: "center",
        className: "distance-label",
      });

    // Build the info section. textContent (not innerHTML) for data fields
    // so nothing in the JSON can ever be interpreted as HTML.
    const sec = document.createElement("section");
    sec.className = "result";
    sec.innerHTML = `
      <div class="result-top">
        <h3 class="result-name"></h3>
        <span class="result-score"></span>
      </div>
      <p class="result-meta"></p>
      <p class="result-desc"></p>
      <p class="result-source"></p>
      <a class="result-link" target="_blank" rel="noopener">Read more on Wikipedia</a>
    `;
    sec.querySelector(".result-name").textContent = `Round ${r.round}: ${r.name}`;
    sec.querySelector(".result-score").textContent = r.score;
    sec.querySelector(".result-meta").textContent = `${r.era}. You were ${r.distance_km} km away.`;
    sec.querySelector(".result-desc").textContent = r.description;
    sec.querySelector(".result-source").textContent = `Sources: ${r.source_citation}`;
    sec.querySelector(".result-link").href = r.wiki_link;

    // Clicking a result zooms the map to that guess/answer pair.
    sec.addEventListener("click", (evt) => {
      if (evt.target.tagName === "A") return;
      map.fitBounds(L.latLngBounds([guess, answer]), { padding: [60, 60], maxZoom: 11 });
    });

    el.results.appendChild(sec);
  });

  // Zoom out so every pin is visible at once.
  map.fitBounds(L.latLngBounds(allPoints), { padding: [80, 80] });
}

// ---------- boot ----------

async function start() {
  try {
    const today = await api("/api/today");
    prompts = today.prompts;
    currentRound = today.guesses_made;

    if (today.complete) {
      const reveal = await api("/api/reveal");
      showReveal(reveal);
    } else {
      showRound(currentRound);
    }
  } catch (err) {
    el.prompt.textContent = "Could not load today's game.";
    el.hint.textContent = err.message;
  }
}

start();
